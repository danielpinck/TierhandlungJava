package verkauf;

public class Technik {
	
	public String name = "Fernbedienung";
	
	private int geraeteAlter = 2;
	
	protected String hersteller = "Sony";
	
	public String getName() {
		return this.name;
	}

}
