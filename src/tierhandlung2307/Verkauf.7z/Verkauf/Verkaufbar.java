package verkauf;

public interface Verkaufbar {
	
	public double sayPrice();

}
