package verkauf;

public enum Qualitaet {
	SCHLECHT, GUT
}
