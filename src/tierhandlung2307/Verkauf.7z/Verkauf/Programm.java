package verkauf;

import java.util.ArrayList;

public class Programm {

	public static void main(String[] args) {
		System.out.println("Hallo im Verkauf.");
		Zubehoer zu = new Zubehoer();

		
		System.out.println(zu.sayPrice());
		
		ArrayList<Zubehoer> liste = new ArrayList<>();
		liste.add(zu);

		System.out.println(zu instanceof Verkaufbar);
		System.out.println(zu instanceof Technik);
		for(Zubehoer i : liste) {
			System.out.println(i.getName());	
		}
		
		if(zu.quali == Qualitaet.GUT) {
			System.out.println("Das Headphone hat gute Qualität.");
		}
		if(zu.quali == Qualitaet.SCHLECHT) {
			System.out.println("Das Headphone hat schlechte Qualität.");
		}

	}

}
