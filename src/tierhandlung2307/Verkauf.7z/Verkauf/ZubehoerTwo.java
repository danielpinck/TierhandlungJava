package verkauf;

public class ZubehoerTwo {
	private String name = "Headphones";
	
	
	public String getName() {
		return this.name;
	}

}
