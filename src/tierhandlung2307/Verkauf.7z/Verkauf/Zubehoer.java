package verkauf;

public class Zubehoer extends Technik implements Verkaufbar {
	
	private String name = "Headphones";
	
	public Qualitaet quali = Qualitaet.SCHLECHT;
	
	public double sayPrice() {
		return 4.99;
	}
	
	@Override
	public String getName() {
		return this.name;
	}
	
	@Override
	public String toString() {
		return "überschrieben";
	}
	

}
